package com.subira.mesh

import android.content.Context
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors

/**
 * Experimental one-to-one WebRTC media. Signaling is carried over the encrypted
 * Nearby data channel. Media itself uses WebRTC ICE on local network interfaces;
 * it may not connect on every Wi-Fi Direct/Bluetooth topology.
 */
class OfflineCallManager(
    context: Context,
    private val sendSignal: (JSONObject) -> Unit,
    private val status: (String) -> Unit
) {
    private val factory: PeerConnectionFactory
    private var peer: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: CameraVideoCapturer? = null
    private val egl = EglBase.create()
    private val executor = Executors.newSingleThreadExecutor()

    init {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context).createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
    }

    private fun createPeer(): PeerConnection {
        peer?.close()
        val config = PeerConnection.RTCConfiguration(emptyList()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            iceTransportsType = PeerConnection.IceTransportsType.ALL
        }
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                status("État média : $state")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onIceCandidate(candidate: IceCandidate) {
                sendSignal(JSONObject().apply {
                    put("type", "ice"); put("sdpMid", candidate.sdpMid)
                    put("sdpMLineIndex", candidate.sdpMLineIndex); put("candidate", candidate.sdp)
                })
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {}
            override fun onTrack(transceiver: RtpTransceiver) {}
        }
        return factory.createPeerConnection(config, observer)!!
    }

    fun startOutgoingCall(withVideo: Boolean) {
        executor.execute {
            try {
                peer = createPeer()
                addLocalTracks(withVideo)
                peer!!.createOffer(object : SdpObserver {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        peer?.setLocalDescription(object : SdpObserverAdapter() {
                            override fun onSetSuccess() {
                                sendSignal(JSONObject().apply {
                                    put("type", "offer"); put("sdp", desc.description)
                                    put("media", if (withVideo) "video" else "audio")
                                })
                                status("Appel envoyé : attente de réponse.")
                            }
                        }, desc)
                    }
                    override fun onSetSuccess() {}
                    override fun onCreateFailure(error: String) { status("Création appel impossible : $error") }
                    override fun onSetFailure(error: String) { status("SDP impossible : $error") }
                }, MediaConstraints())
            } catch (e: Exception) { status("Erreur appel : ${e.localizedMessage}") }
        }
    }

    fun handleSignal(signal: JSONObject) {
        executor.execute {
            try {
                when (signal.optString("type")) {
                    "offer" -> {
                        peer = createPeer()
                        addLocalTracks(signal.optString("media") == "video")
                        val offer = SessionDescription(SessionDescription.Type.OFFER, signal.getString("sdp"))
                        peer!!.setRemoteDescription(object : SdpObserverAdapter() {
                            override fun onSetSuccess() {
                                peer?.createAnswer(object : SdpObserverAdapter() {
                                    override fun onCreateSuccess(desc: SessionDescription) {
                                        peer?.setLocalDescription(object : SdpObserverAdapter() {
                                            override fun onSetSuccess() {
                                                sendSignal(JSONObject().apply {
                                                    put("type", "answer"); put("sdp", desc.description)
                                                })
                                                status("Réponse envoyée.")
                                            }
                                        }, desc)
                                    }
                                    override fun onCreateFailure(error: String) { status("Réponse impossible : $error") }
                                }, MediaConstraints())
                            }
                            override fun onSetFailure(error: String) { status("Offre invalide : $error") }
                        }, offer)
                    }
                    "answer" -> {
                        val answer = SessionDescription(SessionDescription.Type.ANSWER, signal.getString("sdp"))
                        peer?.setRemoteDescription(object : SdpObserverAdapter() {
                            override fun onSetSuccess() { status("Réponse reçue, établissement du média…") }
                            override fun onSetFailure(error: String) { status("Réponse invalide : $error") }
                        }, answer)
                    }
                    "ice" -> peer?.addIceCandidate(IceCandidate(
                        signal.getString("sdpMid"), signal.getInt("sdpMLineIndex"), signal.getString("candidate")
                    ))
                    "hangup" -> stopCall()
                }
            } catch (e: Exception) { status("Signal d'appel invalide : ${e.localizedMessage}") }
        }
    }

    private fun addLocalTracks(withVideo: Boolean) {
        val audioSource = factory.createAudioSource(MediaConstraints())
        audioTrack = factory.createAudioTrack("subira_audio", audioSource)
        peer?.addTrack(audioTrack, listOf("subira_stream"))
        if (withVideo) {
            val enumerator: CameraEnumerator = if (Camera2Enumerator.isSupported(context))
                Camera2Enumerator(context) else Camera1Enumerator(true)
            val camera = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
                ?: enumerator.deviceNames.firstOrNull()
            if (camera != null) {
                capturer = enumerator.createCapturer(camera, null) as? CameraVideoCapturer
                val source = factory.createVideoSource(false)
                capturer?.initialize(SurfaceTextureHelper.create("SubiraCamera", egl.eglBaseContext),
                    null, source.capturerObserver)
                capturer?.startCapture(640, 480, 15)
                videoTrack = factory.createVideoTrack("subira_video", source)
                peer?.addTrack(videoTrack, listOf("subira_stream"))
            }
        }
    }

    fun stopCall() {
        executor.execute {
            sendSignal(JSONObject().put("type", "hangup"))
            runCatching { capturer?.stopCapture() }
            capturer?.dispose(); capturer = null
            audioTrack?.setEnabled(false); videoTrack?.setEnabled(false)
            peer?.close(); peer = null
            status("Appel terminé.")
        }
    }

    fun release() {
        runCatching { capturer?.stopCapture() }
        capturer?.dispose(); peer?.close(); factory.dispose(); egl.release(); executor.shutdown()
    }
}

open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String) {}
    override fun onSetFailure(error: String) {}
}
