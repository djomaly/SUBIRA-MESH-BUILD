package com.subira.mesh

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MeshTransport(
    private val context: Context, private val crypto: CryptoBox,
    private val report: (String) -> Unit,
    private val onMessage: (ChatMessage) -> Unit,
    private val onFile: (File, String) -> Unit,
    private val onCallSignal: (String, JSONObject) -> Unit
) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = "com.subira.mesh.local.v3"
    private val strategy = Strategy.P2P_CLUSTER
    private val connected = ConcurrentHashMap.newKeySet<String>()
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val localName = "SUBIRA-${android.os.Build.MODEL}".take(32)
    private val maxHops = 6
    private val incomingFiles = ConcurrentHashMap<Long, String>()

    private fun envelope(id: String, sender: String, kind: String, body: ByteArray,
                         hops: Int, name: String = ""): ByteArray {
        val json = JSONObject().apply {
            put("v", 3); put("id", id); put("sender", sender); put("kind", kind)
            put("hops", hops); put("name", name)
            put("body", android.util.Base64.encodeToString(body, android.util.Base64.NO_WRAP))
        }.toString().toByteArray()
        return crypto.encrypt(json)
    }
    private fun broadcast(data: ByteArray, except: String? = null) {
        connected.filter { it != except }.forEach { ep ->
            client.sendPayload(ep, Payload.fromBytes(data))
                .addOnFailureListener { report("Envoi vers $ep impossible : ${it.localizedMessage}") }
        }
    }
    private fun receive(from: String, bytes: ByteArray) {
        try {
            val o = JSONObject(String(crypto.decrypt(bytes)))
            if (o.optInt("v") != 3) return
            val id = o.getString("id")
            if (!seen.add(id)) return
            val sender = o.getString("sender")
            val kind = o.getString("kind")
            val hops = o.optInt("hops", 0)
            val body = android.util.Base64.decode(o.getString("body"), android.util.Base64.DEFAULT)
            when (kind) {
                "text" -> onMessage(ChatMessage(id, sender, String(body), System.currentTimeMillis()))
                "call" -> onCallSignal(sender, JSONObject(String(body)))
                "file-meta" -> report("Fichier annoncé : ${o.optString("name")}")
            }
            if (hops > 0) broadcast(envelope(id, sender, kind, body, hops - 1, o.optString("name")), from)
        } catch (_: Exception) { report("Données illisibles : vérifiez la phrase secrète commune.") }
    }
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> payload.asBytes()?.let { receive(endpointId, it) }
                Payload.Type.FILE -> {
                    val f = payload.asFile()?.asJavaFile() ?: return
                    val name = incomingFiles.remove(payload.id) ?: "fichier_recu"
                    onFile(f, name); report("Fichier reçu : $name")
                }
                else -> Unit
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (update.status == PayloadTransferUpdate.Status.FAILURE) report("Transfert échoué.")
        }
    }
    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            report("Demande de connexion : ${info.endpointName}")
            client.acceptConnection(id, payloadCallback)
        }
        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) { connected.add(id); report("Connecté : $id") }
            else report("Connexion refusée : $id")
        }
        override fun onDisconnected(id: String) { connected.remove(id); report("Déconnecté : $id") }
    }
    fun startAdvertising() {
        client.startAdvertising(localName, serviceId, lifecycle,
            AdvertisingOptions.Builder().setStrategy(strategy).build())
            .addOnSuccessListener { report("Téléphone détectable") }
            .addOnFailureListener { report("Erreur : ${it.localizedMessage}") }
    }
    fun startDiscovery() {
        client.startDiscovery(serviceId, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
                report("Trouvé : ${info.endpointName}")
                client.requestConnection(localName, id, lifecycle)
            }
            override fun onEndpointLost(id: String) { report("Appareil hors portée : $id") }
        }, DiscoveryOptions.Builder().setStrategy(strategy).build())
            .addOnFailureListener { report("Recherche impossible : ${it.localizedMessage}") }
    }
    fun sendText(text: String) {
        val id = UUID.randomUUID().toString(); seen.add(id)
        onMessage(ChatMessage(id, localName, text, System.currentTimeMillis(), outgoing = true))
        broadcast(envelope(id, localName, "text", text.toByteArray(), maxHops))
        if (connected.isEmpty()) report("Aucun appareil connecté : message conservé dans l'historique local.")
    }
    fun sendCallSignal(signal: JSONObject) {
        val id = UUID.randomUUID().toString()
        broadcast(envelope(id, localName, "call", signal.toString().toByteArray(), 1))
    }
    fun sendFile(uri: Uri) {
        val resolver = context.contentResolver
        val name = resolver.query(uri, null, null, null, null)?.use { c ->
            val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (ix >= 0 && c.moveToFirst()) c.getString(ix) else null
        } ?: "fichier"
        val temp = File(context.cacheDir, "send_${UUID.randomUUID()}")
        resolver.openInputStream(uri)?.use { input -> FileOutputStream(temp).use { input.copyTo(it) } }
            ?: run { report("Lecture du fichier impossible."); return }
        connected.forEach { ep ->
            val payload = Payload.fromFile(temp); incomingFiles[payload.id] = name
            client.sendPayload(ep, payload)
        }
        report("Transfert direct lancé : $name")
    }
    fun stopAll() {
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints(); connected.clear()
    }
}
