package com.subira.mesh

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var passphrase: EditText
    private lateinit var store: MessageStore
    private var mesh: MeshTransport? = null
    private var calls: OfflineCallManager? = null
    private val pickFile = 72
    private val permissionCode = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MessageStore(this)
        buildScreen()
        requestPermissionsIfNeeded()
        renderHistory()
    }

    private fun buildScreen() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 14)
            setBackgroundColor(Color.rgb(12, 28, 31))
        }
        base.addView(TextView(this).apply {
            text = "SUBIRA MESH"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        })
        status = TextView(this).apply {
            text = "Hors ligne uniquement · aucun mode Internet"
            textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.rgb(95, 220, 180))
            setPadding(0, 8, 0, 8)
        }
        base.addView(status)
        passphrase = EditText(this).apply {
            hint = "Phrase secrète commune (8 caractères minimum)"
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        base.addView(passphrase)
        base.addView(button("Activer le réseau local") { initialiseMesh() })
        base.addView(button("Rendre ce téléphone détectable") {
            if (ensureBluetoothPermissions()) { initialiseMesh(); mesh?.startAdvertising() }
        })
        base.addView(button("Rechercher les téléphones proches") {
            if (ensureBluetoothPermissions()) { initialiseMesh(); mesh?.startDiscovery() }
        })
        input = EditText(this).apply {
            hint = "Écrire un message"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        base.addView(input)
        base.addView(button("Envoyer le message") {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                if (mesh == null) toast("Active d'abord le réseau local.")
                else { mesh?.sendText(text); input.text.clear() }
            }
        })
        base.addView(button("Partager une photo ou un document") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }, pickFile)
        })
        base.addView(TextView(this).apply {
            text = "APPELS LOCAUX"; setTextColor(Color.rgb(95, 220, 180)); setPadding(0, 10, 0, 2)
        })
        base.addView(button("Appel audio") { startCall(false) })
        base.addView(button("Appel vidéo") { startCall(true) })
        base.addView(button("Raccrocher") { calls?.stopCall() })
        base.addView(TextView(this).apply {
            text = "CONVERSATIONS ET JOURNAL"; setTextColor(Color.rgb(95, 220, 180)); setPadding(0, 10, 0, 2)
        })
        val scroll = ScrollView(this)
        log = TextView(this).apply { textSize = 13f; setTextColor(Color.WHITE); setPadding(8, 8, 8, 8) }
        scroll.addView(log); base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(base)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
    }

    private fun initialiseMesh() {
        val phrase = passphrase.text.toString()
        if (phrase.length < 8) { toast("Phrase secrète : 8 caractères minimum."); return }
        mesh?.stopAll()
        val crypto = CryptoBox(phrase.toCharArray(), CryptoBox.ROOM_SALT)
        calls?.release()
        calls = OfflineCallManager(this, { signal -> mesh?.sendCallSignal(signal) }) { msg -> append(msg) }
        mesh = MeshTransport(this, crypto, { append(it) }, { m ->
            store.add(m); runOnUiThread { appendMessage(m) }
        }, { file, name ->
            val destination = File(getExternalFilesDir(null), name)
            runCatching { file.copyTo(destination, overwrite = true) }
            append("Fichier enregistré : ${destination.name}")
        }, { sender, signal ->
            append("Signal d'appel reçu de $sender")
            calls?.handleSignal(signal)
        })
        status.text = "Réseau local prêt · chiffrement activé"
        toast("Même phrase secrète obligatoire sur chaque téléphone.")
    }

    private fun startCall(video: Boolean) {
        if (!ensureCallPermissions()) return
        if (mesh == null) { toast("Active le réseau local et connecte les téléphones avant l'appel."); return }
        calls?.startOutgoingCall(video)
    }

    private fun append(s: String) = runOnUiThread { log.append("\n$s") }
    private fun appendMessage(m: ChatMessage) {
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.timestamp))
        log.append("\n[$t] ${if (m.outgoing) "Moi" else m.sender} : ${m.text}")
    }
    private fun renderHistory() {
        log.text = "Historique local"
        store.read().forEach { appendMessage(it) }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun ensureBluetoothPermissions(): Boolean {
        val missing = bluetoothPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) { ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionCode); return false }
        return true
    }
    private fun ensureCallPermissions(): Boolean {
        val needed = bluetoothPermissions() + listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        val missing = needed.distinct().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) { ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionCode); return false }
        return true
    }
    private fun requestPermissionsIfNeeded() { ensureBluetoothPermissions() }
    private fun bluetoothPermissions(): List<String> {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN; p += Manifest.permission.BLUETOOTH_CONNECT
            p += Manifest.permission.BLUETOOTH_ADVERTISE
        } else p += Manifest.permission.ACCESS_FINE_LOCATION
        return p
    }

    @Deprecated("Legacy document picker callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            if (mesh == null) toast("Active d'abord le réseau local.") else mesh?.sendFile(uri)
        }
    }

    override fun onDestroy() {
        mesh?.stopAll(); calls?.release()
        super.onDestroy()
    }
}
