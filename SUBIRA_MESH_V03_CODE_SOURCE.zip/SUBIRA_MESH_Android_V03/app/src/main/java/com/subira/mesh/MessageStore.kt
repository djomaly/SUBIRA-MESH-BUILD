package com.subira.mesh

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(
    val id: String, val sender: String, val text: String, val timestamp: Long,
    val attachmentName: String? = null, val outgoing: Boolean = false
)

class MessageStore(context: Context) {
    private val prefs = context.getSharedPreferences("subira_messages", Context.MODE_PRIVATE)
    @Synchronized fun add(message: ChatMessage) {
        val all = read().toMutableList()
        if (all.any { it.id == message.id }) return
        all.add(message)
        val arr = JSONArray()
        all.takeLast(500).forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("sender", it.sender); put("text", it.text)
                put("timestamp", it.timestamp); put("attachmentName", it.attachmentName ?: "")
                put("outgoing", it.outgoing)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
    @Synchronized fun read(): List<ChatMessage> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i)
            ChatMessage(o.getString("id"), o.getString("sender"), o.getString("text"),
                o.getLong("timestamp"), o.optString("attachmentName").takeIf { it.isNotBlank() },
                o.optBoolean("outgoing"))
        }.getOrNull() }
    }
}
