package com.subira.mesh

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class CryptoBox(passphrase: CharArray, roomSalt: ByteArray) {
    private val key: SecretKeySpec
    init {
        require(passphrase.size >= 8) { "Phrase secrète trop courte." }
        val spec = javax.crypto.spec.PBEKeySpec(passphrase, roomSalt, 120_000, 256)
        key = SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded, "AES")
        spec.clearPassword()
    }
    fun encrypt(plain: ByteArray): ByteArray {
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        return nonce + c.doFinal(plain)
    }
    fun decrypt(data: ByteArray): ByteArray {
        require(data.size > 12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
        return c.doFinal(data.copyOfRange(12, data.size))
    }
    companion object {
        val ROOM_SALT = "SUBIRA-MESH-ROOM-V1".toByteArray()
    }
}
