plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.subira.mesh"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.subira.mesh"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0"
    }
}
dependencies {
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("org.webrtc:google-webrtc:1.0.32006")
}
