# SUBIRA MESH V0.3 — source Android enrichie

## Ajouts de cette version
- Appels audio et vidéo expérimentaux en WebRTC, avec signalisation transportée dans les messages chiffrés Nearby.
- Boutons Appel audio, Appel vidéo et Raccrocher.
- Permissions micro et caméra.
- La messagerie, l'historique, le transfert direct de fichiers et le relais best-effort de messages restent présents.
- Le mode Internet est retiré du manifeste (permission INTERNET supprimée).

## Limites importantes à lire avant compilation
1. Cette version est un **prototype source non compilé et non testé sur appareils physiques** dans cet environnement.
2. WebRTC transporte les médias via ICE sur les interfaces réseau locales. Nearby transporte la signalisation. Cela peut fonctionner si les téléphones ont une route IP locale l'un vers l'autre; ce n'est pas garanti lorsque la connexion radio Nearby repose sur une topologie propriétaire Bluetooth/Wi-Fi Direct sans connectivité IP exploitable.
3. Le moteur n'a pas encore d'interface d'aperçu vidéo distante ou locale; l'appel vidéo tente de capturer et transmettre la caméra, mais l'écran ne présente pas encore les flux vidéo. Il faut ajouter SurfaceViewRenderer et tester les flux.
4. Le routage média multipoint n'est pas implémenté. Les appels sont prévus en un-à-un; les conférences exigent une architecture SFU ou mesh média et beaucoup plus de tests.
5. Les fichiers sont envoyés directement aux pairs connectés, pas relayés en multi-sauts.
6. Le chiffrement AES-GCM utilise une phrase secrète commune; ce n'est pas encore un système complet de gestion d'identités/clefs. Protéger cette phrase.
7. Nearby Connections dépend des services Google Play. La permission INTERNET est retirée du manifeste, mais la bibliothèque Google Play Services peut nécessiter un environnement compatible et les dépendances Gradle sont téléchargées lors de la compilation.
8. La compilation Android peut échouer à cause de différences d'API WebRTC selon l'artefact/version. Résoudre les erreurs de compilation et tester sur au moins deux appareils est obligatoire avant distribution.

## Test
- Installer sur deux téléphones Android 8 ou plus.
- Autoriser Bluetooth, micro et caméra.
- Saisir la même phrase secrète (au moins 8 caractères).
- Connecter les appareils via la fonction de découverte Nearby.
- Tester les messages d'abord.
- Tester l'appel audio, puis l'appel vidéo.
- Pour le média, vérifier que les deux téléphones disposent d'une connectivité IP locale entre eux. La simple détection Nearby ne garantit pas cela.

Application ID : com.subira.mesh
Version : 0.3.0
Minimum Android : API 26
Compile SDK : 35
